package PlayersAndMonsters_03_85_100;

public class SoulMaster extends DarkWizard{
    public SoulMaster(String username, int level) {
        super(username, level);
    }
}
