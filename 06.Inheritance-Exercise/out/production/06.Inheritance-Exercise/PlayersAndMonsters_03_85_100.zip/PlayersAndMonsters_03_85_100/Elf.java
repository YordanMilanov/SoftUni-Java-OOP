package PlayersAndMonsters_03_85_100;

public class Elf extends Hero{
    public Elf(String username, int level) {
        super(username, level);
    }
}
