package PlayersAndMonsters_03_85_100;

public class DarkWizard extends Wizard{
    public DarkWizard(String username, int level) {
        super(username, level);
    }
}
