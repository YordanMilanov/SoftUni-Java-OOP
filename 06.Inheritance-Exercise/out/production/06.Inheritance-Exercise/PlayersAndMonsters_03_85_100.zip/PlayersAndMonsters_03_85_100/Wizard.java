package PlayersAndMonsters_03_85_100;

public class Wizard extends Hero{
    public Wizard(String username, int level) {
        super(username, level);
    }
}
