package PlayersAndMonsters_03_85_100;

public class Main {
    public static void main(String[] args) {

    }
}
