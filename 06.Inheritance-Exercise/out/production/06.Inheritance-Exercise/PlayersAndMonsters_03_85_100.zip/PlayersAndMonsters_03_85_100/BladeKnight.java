package PlayersAndMonsters_03_85_100;

public class BladeKnight extends DarkKnight{
    public BladeKnight(String username, int level) {
        super(username, level);
    }
}
