package Telephony_05_75_100;

public interface Callable {
    String call ();
}
