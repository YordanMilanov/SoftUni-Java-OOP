package Telephony_05_75_100;

public interface Browsable {
    String browse();
}
