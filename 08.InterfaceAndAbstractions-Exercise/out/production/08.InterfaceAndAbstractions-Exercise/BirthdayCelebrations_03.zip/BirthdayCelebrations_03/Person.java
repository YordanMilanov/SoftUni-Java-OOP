package BirthdayCelebrations_03;

public interface Person {
    String getName();
    int getAge();
}
