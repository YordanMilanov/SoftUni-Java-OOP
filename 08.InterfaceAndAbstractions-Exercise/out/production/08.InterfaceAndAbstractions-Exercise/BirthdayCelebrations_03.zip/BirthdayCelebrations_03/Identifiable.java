package BirthdayCelebrations_03;

public interface Identifiable {
    String getId();
}
