package WildFarm_03;

public abstract class Feline extends Mammal{

    public Feline(String animalName, String animalType, Double weight, String livingRegion) {
        super(animalName, animalType, weight, livingRegion);
    }


}
