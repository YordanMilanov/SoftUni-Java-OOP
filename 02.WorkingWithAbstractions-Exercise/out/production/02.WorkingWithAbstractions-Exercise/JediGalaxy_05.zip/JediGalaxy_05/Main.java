package JediGalaxy_05;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static long sum = 0;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] dimensions = Arrays
                .stream(scanner.nextLine().split(" "))
                .mapToInt(Integer::parseInt)
                .toArray();
        int rows = dimensions[0];
        int cols = dimensions[1];

        int[][] matrix = new int[rows][cols];

        intializeMatrix(rows, cols, matrix);

        String commands = scanner.nextLine();
        while (!commands.equals("Let the Force be with you")) {
            int[] heroCoordinates = Arrays.stream(commands.split("\\s+")).mapToInt(Integer::parseInt).toArray();
            int[] evilCoordinates = Arrays.stream(scanner.nextLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();
            int rowEvil = evilCoordinates[0];
            int colEvil = evilCoordinates[1];

            moveCoordinatesEvil(matrix, rowEvil, colEvil);

            int heroRow = heroCoordinates[0];
            int heroCol = heroCoordinates[1];

            moveCoordinatesHero(matrix, heroRow, heroCol);
            commands = scanner.nextLine();
        }
        System.out.println(sum);
    }

    private static void moveCoordinatesEvil(int[][] matrix, int x, int y) {
        while (x >= 0 && y >= 0) {
            if (x < matrix.length && y < matrix[0].length) {
                    matrix[x][y] = 0;
            }
            x--;
            y--;
        }
    }

    private static void moveCoordinatesHero(int[][] matrix, int x, int y) {

        while (x < 0 || y < 0) {
            x--;
            y++;
        }
        while (x < matrix.length && y < matrix[0].length && x >= 0 && y >= 0) {
                    sum += matrix[x][y];
            x--;
            y++;
        }
    }

    private static void intializeMatrix(int rows, int cols, int[][] matrix) {
        int value = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = value++;
            }
        }
    }
}
