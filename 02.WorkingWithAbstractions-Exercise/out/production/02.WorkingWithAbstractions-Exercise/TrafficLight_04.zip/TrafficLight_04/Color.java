package TrafficLight_04;

public enum Color {
    RED,
    YELLOW,
    GREEN;


}
